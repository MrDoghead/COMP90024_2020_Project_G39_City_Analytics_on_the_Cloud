## run two harvesters seperately by command

```bash
python3 harvester1.py
```

```bash
python3 harvester2.py
```
